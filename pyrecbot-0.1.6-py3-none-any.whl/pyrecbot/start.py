import pyrecbot
pyrecbot.record()
