Pyrecbot 0.1.5

This module is used to automate keyboard and mouse functions.

Basic Functions

**start the bot's action recorder**

syntax:

pyrecbot.start()

to stop recording **press ctrl+b** while recording

